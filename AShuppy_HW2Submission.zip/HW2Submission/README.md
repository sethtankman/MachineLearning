# MachineLearning

This is a machine learning library developed by Addison Shuppy for CS5350/CS6350

Each folder contains a run.sh file which runs each relevant python file in sequence.
