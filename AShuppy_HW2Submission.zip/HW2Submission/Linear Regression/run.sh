#!/bin/sh
python BatchGradientDescent.py
python Stochastic.py