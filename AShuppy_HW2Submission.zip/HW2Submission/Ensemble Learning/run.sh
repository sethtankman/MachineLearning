#!/bin/sh
python bagging.py
python bagging-1.py
python ensemble.py
python randomForests.py
python randomForests_1.py